<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Pixel CMS - Master' ?></title>
    <link rel="stylesheet" href="<?= asset('css/master.css') ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #0f172a;
            --card-bg: #1e293b;
            --accent-primary: #38bdf8;
            --accent-secondary: #818cf8;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --border-color: #334155;
        }

        body {
            margin: 0;
            padding: 0;
            background-color: var(--bg-color);
            color: var(--text-main);
            font-family: 'Outfit', sans-serif;
            display: flex;
            min-height: 100vh;
        }

        aside {
            width: 280px;
            background-color: var(--card-bg);
            border-right: 1px solid var(--border-color);
            padding: 2rem;
            display: flex;
            flex-direction: column;
        }

        main {
            flex: 1;
            padding: 2rem;
            overflow-y: auto;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: 600;
            background: linear-gradient(to right, var(--accent-primary), var(--accent-secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 3rem;
        }

        nav ul {
            list-style: none;
            padding: 0;
        }

        nav ul li a {
            color: var(--text-muted);
            text-decoration: none;
            display: block;
            padding: 0.75rem 1rem;
            border-radius: 0.5rem;
            transition: all 0.3s ease;
            margin-bottom: 0.5rem;
        }

        nav ul li a:hover, nav ul li a.active {
            background-color: var(--accent-primary);
            color: white;
            box-shadow: 0 4px 12px rgba(56, 189, 248, 0.3);
        }

        .card {
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 1rem;
            padding: 1.5rem;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        }

        h1 { margin-top: 0; }
        
        .btn {
            display: inline-block;
            padding: 0.75rem 1.5rem;
            border-radius: 0.5rem;
            text-decoration: none;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: opacity 0.3s ease;
        }

        .btn-primary { background-color: var(--accent-primary); color: white; }
        .btn-secondary { background-color: var(--border-color); color: white; }
    </style>
</head>
<body>
    <aside>
        <div class="logo">PixelCMS Master</div>
        <nav>
            <ul>
                <li><a href="/master" class="active">Dashboard</a></li>
                <li><a href="/master/empresas/crear">Nueva Empresa</a></li>
                <li><a href="/master/licencias/crear">Nueva Licencia</a></li>
                <li><a href="/master/config">Configuración</a></li>
            </ul>
        </nav>
    </aside>
    <main>
        <?= $content ?>
    </main>
</body>
</html>
